 package com.bank.ui;

import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.layout.*;

public class AccountDetailsView {

    public Parent getView() {
        VBox root = new VBox(20);
        root.setPadding(new Insets(30));
        root.setStyle("-fx-background-color: #070F1E;");

        Label heading = new Label("👤 NOVARA Account Details");
        heading.setStyle("-fx-text-fill: #FFD700; -fx-font-size: 24px; -fx-font-weight: bold;");

        VBox card = new VBox(15);
        card.getStyleClass().add("calc-card-container");

        GridPane grid = new GridPane();
        grid.setHgap(25);
        grid.setVgap(18);

        addDetailRow(grid, 0, "Customer Name:", "Visalakshi Satya Shanmukha Chintapalli");
        addDetailRow(grid, 1, "Account Number:", "NVR-9876543210");
        addDetailRow(grid, 2, "Account Type:", "Savings Premium Account");
        addDetailRow(grid, 3, "Available Balance:", "₹ 4,85,920.50");
        addDetailRow(grid, 4, "Account Status:", "ACTIVE / VERIFIED (KYC COMPLETE)");
        addDetailRow(grid, 5, "Branch Code & IFSC:", "NOV-VJWD-004 / NOVR0009876");

        card.getChildren().addAll(grid);
        root.getChildren().addAll(heading, card);
        return root;
    }

    private void addDetailRow(GridPane grid, int row, String labelText, String valText) {
        Label lbl = new Label(labelText);
        lbl.setStyle("-fx-text-fill: #00F2FE; -fx-font-size: 14px; -fx-font-weight: bold;");
        Label val = new Label(valText);
        val.setStyle("-fx-text-fill: #FFFFFF; -fx-font-size: 15px; -fx-font-weight: bold;");
        grid.add(lbl, 0, row);
        grid.add(val, 1, row);
    }
}