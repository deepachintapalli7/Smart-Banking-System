 package com.bank;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import com.bank.ui.LoginView;
import com.bank.ui.NavigationController;

public class MainApp extends Application {

    private static Stage primaryStage;

    @Override
    public void start(Stage stage) {
        primaryStage = stage;
        primaryStage.setTitle("Smart Banking System - Enterprise Portal");
        showLogin();
    }

    public static void showLogin() {
        try {
            LoginView loginView = new LoginView();
            Scene scene = new Scene(loginView.getView(NavigationController::navigateToDashboard), 900, 650);
            NavigationController.applyCSS(scene);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Stage getPrimaryStage() {
        return primaryStage;
    }

    public static void main(String[] args) {
        launch(args);
    }
}