 package com.bank.ui;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

public class TransactionHistoryView {
    public static VBox getView() {
        VBox card = new VBox(15);
        card.getStyleClass().add("card-panel");

        Label title = new Label("Transaction History");
        title.getStyleClass().add("header-text");

        TableView<String> table = new TableView<>();
        TableColumn<String, String> col1 = new TableColumn<>("Txn ID");
        TableColumn<String, String> col2 = new TableColumn<>("Type");
        TableColumn<String, String> col3 = new TableColumn<>("Amount (₹)");
        TableColumn<String, String> col4 = new TableColumn<>("Date & Time");
        TableColumn<String, String> col5 = new TableColumn<>("Description");
        TableColumn<String, String> col6 = new TableColumn<>("Status");

        table.getColumns().addAll(col1, col2, col3, col4, col5, col6);
        table.setPlaceholder(new Label("No transactions available. Waiting for backend integration."));

        card.getChildren().addAll(title, table);
        return new VBox(card) {{ setPadding(new Insets(20)); }};
    }
}
