 package com.bank.ui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

public class LoginView {

    public Parent getView(Runnable onLoginSuccess) {
        VBox root = new VBox();
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-background-color: #070F1E;");

        VBox card = new VBox(20);
        card.setAlignment(Pos.CENTER);
        card.setMaxWidth(400);
        card.setPadding(new Insets(40));
        card.getStyleClass().add("hdfc-card");

        Label logo = new Label("NOVARA BANK");
        logo.setStyle("-fx-text-fill: #64FFDA; -fx-font-size: 28px; -fx-font-weight: bold; -fx-letter-spacing: 2px;");

        Label subtitle = new Label("Enterprise Digital Banking Portal");
        subtitle.setStyle("-fx-text-fill: #8892B0; -fx-font-size: 13px;");

        VBox form = new VBox(14);
        
        Label userLabel = new Label("Username / Customer ID");
        userLabel.setStyle("-fx-text-fill: #CCD6F6; -fx-font-size: 12px;");
        TextField usernameField = new TextField("shanmukha");
        usernameField.getStyleClass().add("text-input");

        Label passLabel = new Label("Password");
        passLabel.setStyle("-fx-text-fill: #CCD6F6; -fx-font-size: 12px;");
        PasswordField passwordField = new PasswordField();
        passwordField.setText("admin123");
        passwordField.getStyleClass().add("text-input");

        form.getChildren().addAll(userLabel, usernameField, passLabel, passwordField);

        Button loginBtn = new Button("SECURE LOG IN");
        loginBtn.setMaxWidth(Double.MAX_VALUE);
        loginBtn.getStyleClass().add("btn-hdfc-primary");

        loginBtn.setOnAction(e -> {
            if (onLoginSuccess != null) onLoginSuccess.run();
        });

        card.getChildren().addAll(logo, subtitle, form, loginBtn);
        root.getChildren().add(card);
        return root;
    }
}