 
package com.bank.ui;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

public class WithdrawView {
    public static VBox getView() {
        VBox card = new VBox(15);
        card.getStyleClass().add("card-panel");
        card.setMaxWidth(450);

        Label title = new Label("Withdraw Funds");
        title.getStyleClass().add("header-text");

        TextField accField = new TextField();
        accField.setPromptText("Account Number");
        accField.getStyleClass().add("text-input-field");

        TextField amtField = new TextField();
        amtField.setPromptText("Withdrawal Amount (₹)");
        amtField.getStyleClass().add("text-input-field");

        Button confirmBtn = new Button("Confirm Withdrawal");
        confirmBtn.getStyleClass().add("primary-button");

        confirmBtn.setOnAction(e -> {
            if (accField.getText().trim().isEmpty() || amtField.getText().trim().isEmpty()) {
                NavigationController.showAlert(Alert.AlertType.ERROR, "Input Error", "Please fill all fields.");
                return;
            }
            try {
                double amt = Double.parseDouble(amtField.getText());
                if (amt <= 0) {
                    NavigationController.showAlert(Alert.AlertType.ERROR, "Input Error", "Amount must be greater than zero.");
                    return;
                }
                NavigationController.showAlert(Alert.AlertType.INFORMATION, "Processing", "Withdrawal request submitted to backend.");
            } catch (NumberFormatException ex) {
                NavigationController.showAlert(Alert.AlertType.ERROR, "Input Error", "Amount must be numeric.");
            }
        });

        card.getChildren().addAll(title, accField, amtField, confirmBtn);
        return new VBox(card) {{ setPadding(new Insets(20)); }};
    }
}