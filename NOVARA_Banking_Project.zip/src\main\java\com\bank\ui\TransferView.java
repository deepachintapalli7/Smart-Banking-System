 package com.bank.ui;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

public class TransferView {
    public static VBox getView() {
        VBox card = new VBox(15);
        card.getStyleClass().add("card-panel");
        card.setMaxWidth(450);

        Label title = new Label("Fund Transfer");
        title.getStyleClass().add("header-text");

        TextField senderField = new TextField();
        senderField.setPromptText("Sender Account No");
        senderField.getStyleClass().add("text-input-field");

        TextField receiverField = new TextField();
        receiverField.setPromptText("Receiver Account No");
        receiverField.getStyleClass().add("text-input-field");

        TextField amtField = new TextField();
        amtField.setPromptText("Transfer Amount (₹)");
        amtField.getStyleClass().add("text-input-field");

        Button confirmBtn = new Button("Transfer Funds");
        confirmBtn.getStyleClass().add("primary-button");

        confirmBtn.setOnAction(e -> {
            if (senderField.getText().trim().isEmpty() || receiverField.getText().trim().isEmpty() || amtField.getText().trim().isEmpty()) {
                NavigationController.showAlert(Alert.AlertType.ERROR, "Input Error", "All fields are required.");
                return;
            }
            try {
                double amt = Double.parseDouble(amtField.getText());
                if (amt <= 0) {
                    NavigationController.showAlert(Alert.AlertType.ERROR, "Input Error", "Transfer amount must be greater than zero.");
                    return;
                }
                NavigationController.showAlert(Alert.AlertType.INFORMATION, "Processing", "Transfer request submitted to backend.");
            } catch (NumberFormatException ex) {
                NavigationController.showAlert(Alert.AlertType.ERROR, "Input Error", "Amount must be a numeric value.");
            }
        });

        card.getChildren().addAll(title, senderField, receiverField, amtField, confirmBtn);
        return new VBox(card) {{ setPadding(new Insets(20)); }};
    }
}