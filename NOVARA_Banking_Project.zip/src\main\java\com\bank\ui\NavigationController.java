 package com.bank.ui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import com.bank.MainApp;

public class NavigationController {

    private static BorderPane rootLayout = new BorderPane();

    public static BorderPane getRootLayout() {
        return rootLayout;
    }

    public static VBox createSidebar() {
        VBox sidebar = new VBox(8);
        sidebar.setPadding(new Insets(20, 15, 20, 15));
        sidebar.setStyle("-fx-background-color: #020C1B; -fx-min-width: 250px; -fx-border-color: #172A45; -fx-border-width: 0 1 0 0;");

        // Top Brand Logo - NOVARA BANK
        HBox brandBox = new HBox(10);
        brandBox.setAlignment(Pos.CENTER_LEFT);
        brandBox.setPadding(new Insets(0, 0, 20, 10));

        Label brand = new Label("NOVARA BANK");
        brand.setStyle("-fx-text-fill: #64FFDA; -fx-font-size: 20px; -fx-font-weight: bold; -fx-letter-spacing: 1px;");
        brandBox.getChildren().add(brand);

        NavigationController nav = new NavigationController();

        Button btnDashboard = createNavButton("📊  Dashboard Overview", () -> setCenterView(new DashboardView().getView(nav)));
        Button btnAccount = createNavButton("👤  My Account Details", () -> setCenterView(new AccountDetailsView().getView()));
        Button btnDeposit = createNavButton("💵  Deposit Funds", () -> setCenterView(new DepositView().getView()));
        Button btnWithdraw = createNavButton("🏧  Withdraw Funds", () -> setCenterView(new WithdrawView().getView()));
        Button btnTransfer = createNavButton("💸  Fund Transfer (IMPS)", () -> setCenterView(new TransferView().getView()));
        Button btnHistory = createNavButton("📜  Passbook / History", () -> setCenterView(new TransactionHistoryView().getView()));
        Button btnStatement = createNavButton("📑  Account Statement", () -> setCenterView(new StatementView().getView()));
        Button btnLogout = createNavButton("🚪  Secure Logout", () -> MainApp.showLogin());

        sidebar.getChildren().addAll(brandBox, btnDashboard, btnAccount, btnDeposit, btnWithdraw, btnTransfer, btnHistory, btnStatement, btnLogout);
        return sidebar;
    }

    private static Button createNavButton(String text, Runnable action) {
        Button btn = new Button(text);
        btn.setMaxWidth(Double.MAX_VALUE);
        btn.getStyleClass().add("sidebar-link");
        btn.setOnAction(e -> action.run());
        return btn;
    }

    public static void setCenterView(Node view) {
        rootLayout.setCenter(view);
    }

    public void navigateTo(Node view) {
        setCenterView(view);
    }

    public static void navigateToDashboard() {
        NavigationController nav = new NavigationController();
        rootLayout.setLeft(createSidebar());
        rootLayout.setCenter(new DashboardView().getView(nav));

        Scene scene = new Scene(rootLayout, 1150, 720);
        applyCSS(scene);
        MainApp.getPrimaryStage().setScene(scene);
    }

    public static void applyCSS(Scene scene) {
        try {
            var css = NavigationController.class.getResource("/css/style.css");
            if (css != null) {
                scene.getStylesheets().add(css.toExternalForm());
            }
        } catch (Exception ignored) {}
    }

    public static void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}