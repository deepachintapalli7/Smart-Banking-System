 package com.bank.ui;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;

public class StatementView {
    public static VBox getView() {
        VBox card = new VBox(15);
        card.getStyleClass().add("card-panel");

        Label title = new Label("Account Statement Generator");
        title.getStyleClass().add("header-text");

        HBox dates = new HBox(15);
        DatePicker start = new DatePicker();
        DatePicker end = new DatePicker();
        start.setPromptText("Start Date");
        end.setPromptText("End Date");
        dates.getChildren().addAll(new Label("From:") {{ getStyleClass().add("label-text"); }}, start, 
                                   new Label("To:") {{ getStyleClass().add("label-text"); }}, end);

        Button genBtn = new Button("Generate Statement");
        genBtn.getStyleClass().add("primary-button");

        TextArea output = new TextArea("Select date range and click Generate Statement...");
        output.getStyleClass().add("text-input-field");
        output.setPrefHeight(200);

        genBtn.setOnAction(e -> {
            if (start.getValue() == null || end.getValue() == null) {
                NavigationController.showAlert(Alert.AlertType.ERROR, "Input Error", "Please select start and end dates.");
            } else {
                output.setText("Statement generated for period: " + start.getValue() + " to " + end.getValue() + "\n(Sample Data Output)");
            }
        });

        card.getChildren().addAll(title, dates, genBtn, output);
        return new VBox(card) {{ setPadding(new Insets(20)); }};
    }
}
