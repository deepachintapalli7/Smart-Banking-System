 package com.bank.ui;

import javafx.animation.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;
import javafx.util.Duration;

public class DashboardView {

    public static class Transaction {
        private final SimpleStringProperty id, type, amount, date, status;
        public Transaction(String id, String type, String amount, String date, String status) {
            this.id = new SimpleStringProperty(id);
            this.type = new SimpleStringProperty(type);
            this.amount = new SimpleStringProperty(amount);
            this.date = new SimpleStringProperty(date);
            this.status = new SimpleStringProperty(status);
        }
        public String getId() { return id.get(); }
        public String getType() { return type.get(); }
        public String getAmount() { return amount.get(); }
        public String getDate() { return date.get(); }
        public String getStatus() { return status.get(); }
    }

    public Parent getView(NavigationController nav) {
        VBox rootBox = new VBox();
        rootBox.setStyle("-fx-background-color: #FFFFFF;");

        // ==========================================
        // 1. HERO TOP SECTION (DEEP INDIGO & FLOATING ANIMATIONS)
        // ==========================================
        VBox heroSection = new VBox(25);
        heroSection.getStyleClass().add("hero-header-section");

        HBox bubbleBar = new HBox();
        bubbleBar.setAlignment(Pos.CENTER_LEFT);

        Label bubbleLeft = new Label("💬 NOVARA AI");
        bubbleLeft.getStyleClass().add("floating-bubble");
        bubbleLeft.setStyle("-fx-text-fill: #FFFFFF; -fx-font-weight: bold; -fx-font-size: 11px;");

        Region bubbleSpacer = new Region();
        HBox.setHgrow(bubbleSpacer, Priority.ALWAYS);

        Label bubbleRight = new Label("💬 24x7 SUPPORT");
        bubbleRight.getStyleClass().add("floating-bubble");
        bubbleRight.setStyle("-fx-text-fill: #FFFFFF; -fx-font-weight: bold; -fx-font-size: 11px;");

        bubbleBar.getChildren().addAll(bubbleLeft, bubbleSpacer, bubbleRight);

        addFloatingAnimation(bubbleLeft, -8, 2.2);
        addFloatingAnimation(bubbleRight, 8, 2.6);

        GridPane heroGrid = new GridPane();
        heroGrid.setHgap(30);

        VBox heroLeft = new VBox(15);
        
        Label title1 = new Label("Turn Your Financial");
        title1.getStyleClass().add("hero-white-title");

        Label title2 = new Label("Goals Into");
        title2.getStyleClass().add("hero-white-title");

        Label title3 = new Label("Digital Realities");
        title3.getStyleClass().add("hero-pink-title");

        SVGPath underlinePath = new SVGPath();
        underlinePath.setContent("M 0 0 Q 120 12 240 0");
        underlinePath.getStyleClass().add("hero-mint-underline");

        VBox titleContainer = new VBox(2, title1, title2, title3, underlinePath);

        Label subtitle = new Label("Are you ready to elevate your wealth portfolio? NOVARA Bank turns your personal savings, education loans, and investment ideas into digital realities.");
        subtitle.getStyleClass().add("hero-subtitle");
        subtitle.setWrapText(true);
        subtitle.setMaxWidth(480);

        HBox ctaBox = new HBox(12);
        ctaBox.setAlignment(Pos.CENTER_LEFT);

        Button btnTalk = new Button("Let's talk — Limited Time Offer");
        btnTalk.getStyleClass().add("btn-cta-white");

        Label discountBadge = new Label("20%\nOFF");
        discountBadge.getStyleClass().add("badge-discount-pink");
        discountBadge.setStyle("-fx-text-fill: #FFFFFF; -fx-font-size: 9px; -fx-font-weight: bold; -fx-text-alignment: center;");

        addFloatingAnimation(discountBadge, -6, 1.8);

        ctaBox.getChildren().addAll(btnTalk, discountBadge);
        heroLeft.getChildren().addAll(titleContainer, subtitle, ctaBox);

        VBox heroRight = new VBox(15);
        heroRight.getStyleClass().add("laptop-graphic-box");
        heroRight.setAlignment(Pos.CENTER);

        Label laptopDisplay = new Label("💻 NOVARA PORTAL");
        laptopDisplay.setStyle("-fx-text-fill: #FF5A78; -fx-font-weight: bold; -fx-font-size: 20px;");

        Label urlBar = new Label("http://www.novarabank.com/dashboard");
        urlBar.setStyle("-fx-background-color: #1E2346; -fx-text-fill: #00E6A5; -fx-padding: 6px 14px; -fx-background-radius: 8px; -fx-font-family: monospace;");

        VBox mockStats = new VBox(8);
        mockStats.setStyle("-fx-background-color: rgba(0,0,0,0.3); -fx-padding: 15px; -fx-background-radius: 10px;");
        mockStats.getChildren().addAll(
            new Label("💰 Total Capital: ₹ 7,85,920.50"),
            new Label("🎓 Edu Loan Balance: ₹ 4,50,000.00"),
            new Label("🛡️ Status: Encrypted & Verified")
        );
        for(javafx.scene.Node n : mockStats.getChildren()) {
            n.setStyle("-fx-text-fill: #FFFFFF; -fx-font-weight: bold; -fx-font-size: 12px;");
        }

        heroRight.getChildren().addAll(laptopDisplay, urlBar, mockStats);
        addFloatingAnimation(heroRight, -10, 3.0);

        heroGrid.add(heroLeft, 0, 0);
        heroGrid.add(heroRight, 1, 0);

        ColumnConstraints col1 = new ColumnConstraints(); col1.setPercentWidth(55);
        ColumnConstraints col2 = new ColumnConstraints(); col2.setPercentWidth(45);
        heroGrid.getColumnConstraints().addAll(col1, col2);

        heroSection.getChildren().addAll(bubbleBar, heroGrid);

        // ==========================================
        // 2. WHITE BOTTOM SECTION (SERVICES, FD & TRANSACTIONS)
        // ==========================================
        VBox bottomSection = new VBox(25);
        bottomSection.getStyleClass().add("white-bottom-section");

        // A. ENTERPRISE SERVICES HUB GRID
        Label servicesTitle = new Label("⚡ NOVARA Banking Services & Portals");
        servicesTitle.setStyle("-fx-text-fill: #1E2346; -fx-font-size: 22px; -fx-font-weight: bold;");

        GridPane servicesGrid = new GridPane();
        servicesGrid.setHgap(15);
        servicesGrid.setVgap(15);

        VBox s1 = createLightServiceCard("🎓 Education Loan Portal", "Apply Instant College Tuition Loans", "Apply Loan");
        VBox s2 = createLightServiceCard("🥇 Gold Loan Valuation", "Instant Gold valuation & credit", "Claim Gold Loan");
        VBox s3 = createLightServiceCard("🛡️ Insurance Suite", "Life, Health & Term Cover Plans", "View Plans");
        VBox s4 = createLightServiceCard("💳 PAN Card Linkage", "Apply / Link PAN with Bank A/C", "Link PAN");
        VBox s5 = createLightServiceCard("👶 Minor to Major A/C", "Upgrade Account Status upon 18", "Upgrade A/C");
        VBox s6 = createLightServiceCard("💰 Fixed & Recurring Deposit", "FD Compounding & Monthly RD", "Start FD / RD");

        servicesGrid.add(s1, 0, 0); servicesGrid.add(s2, 1, 0); servicesGrid.add(s3, 2, 0);
        servicesGrid.add(s4, 0, 1); servicesGrid.add(s5, 1, 1); servicesGrid.add(s6, 2, 1);

        for (int i = 0; i < 3; i++) {
            ColumnConstraints cc = new ColumnConstraints();
            cc.setPercentWidth(33.33);
            servicesGrid.getColumnConstraints().add(cc);
        }

        // B. FIXED DEPOSIT COMPOUNDING SIMULATOR (Light Theme Card)
        VBox fdContainer = new VBox(15);
        fdContainer.setStyle("-fx-background-color: #F8FAFC; -fx-padding: 20px; -fx-background-radius: 14px; -fx-border-color: #E2E8F0; -fx-border-radius: 14px;");

        Label fdTitle = new Label("📈 Fixed Deposit (FD) Compounding Growth Simulator");
        fdTitle.setStyle("-fx-text-fill: #1E2346; -fx-font-size: 18px; -fx-font-weight: bold;");

        GridPane fdGrid = new GridPane();
        fdGrid.setHgap(20);
        fdGrid.setVgap(15);

        Label principalLabel = new Label("Deposit Amount (₹):");
        principalLabel.setStyle("-fx-text-fill: #475569; -fx-font-size: 13px; -fx-font-weight: bold;");
        TextField principalField = new TextField("100000");
        principalField.setStyle("-fx-background-color: #FFFFFF; -fx-border-color: #CBD5E1; -fx-border-radius: 6px; -fx-padding: 8px; -fx-font-weight: bold;");

        Label tenureLabel = new Label("Tenure (Years):");
        tenureLabel.setStyle("-fx-text-fill: #475569; -fx-font-size: 13px; -fx-font-weight: bold;");
        Slider tenureSlider = new Slider(1, 10, 5);
        Label tenureValueLabel = new Label("5 Years");
        tenureValueLabel.setStyle("-fx-text-fill: #FF5A78; -fx-font-weight: bold;");

        Button calcFdBtn = new Button("Calculate Maturity Growth 🚀");
        calcFdBtn.setStyle("-fx-background-color: linear-gradient(to right, #1E2346, #2B3369); -fx-text-fill: #FFFFFF; -fx-font-weight: bold; -fx-padding: 10px 20px; -fx-background-radius: 20px; -fx-cursor: hand;");

        VBox fdResultCard = new VBox(8);
        fdResultCard.setStyle("-fx-background-color: #1E2346; -fx-padding: 18px; -fx-background-radius: 12px;");
        fdResultCard.setAlignment(Pos.CENTER);

        Label maturityHeading = new Label("Estimated Maturity Value (7.5% Compound Interest)");
        maturityHeading.setStyle("-fx-text-fill: #A0A9D0; -fx-font-size: 12px;");

        Label maturityAmountLabel = new Label("₹ 1,43,562.93");
        maturityAmountLabel.setStyle("-fx-text-fill: #00E6A5; -fx-font-size: 24px; -fx-font-weight: bold;");

        Label profitEarnedLabel = new Label("Total Interest Earned: ₹ 43,562.93");
        profitEarnedLabel.setStyle("-fx-text-fill: #FF8359; -fx-font-size: 12px; -fx-font-weight: bold;");

        fdResultCard.getChildren().addAll(maturityHeading, maturityAmountLabel, profitEarnedLabel);

        Runnable calculateFD = () -> {
            try {
                double p = Double.parseDouble(principalField.getText());
                double r = 7.5 / 100;
                double t = tenureSlider.getValue();
                
                double maturityValue = p * Math.pow(1 + r, t);
                double interestEarned = maturityValue - p;

                maturityAmountLabel.setText(String.format("₹ %,.2f", maturityValue));
                profitEarnedLabel.setText(String.format("Total Interest Earned: ₹ %,.2f", interestEarned));
                tenureValueLabel.setText(String.format("%.0f Years", t));
            } catch (Exception ex) {
                maturityAmountLabel.setText("Invalid Input");
            }
        };

        calcFdBtn.setOnAction(e -> calculateFD.run());
        tenureSlider.valueProperty().addListener((obs, oldV, newV) -> calculateFD.run());

        VBox fdControls = new VBox(12);
        fdControls.getChildren().addAll(
            new HBox(10, principalLabel, principalField),
            new HBox(10, tenureLabel, tenureSlider, tenureValueLabel),
            calcFdBtn
        );

        fdGrid.add(fdControls, 0, 0);
        fdGrid.add(fdResultCard, 1, 0);

        ColumnConstraints c1 = new ColumnConstraints(); c1.setPercentWidth(55);
        ColumnConstraints c2 = new ColumnConstraints(); c2.setPercentWidth(45);
        fdGrid.getColumnConstraints().addAll(c1, c2);

        fdContainer.getChildren().addAll(fdTitle, fdGrid);

        // C. UNIFIED PASSBOOK TRANSACTIONS TABLE
        Label whyTitle = new Label("📜 Recent Passbook & Service Transactions");
        whyTitle.setStyle("-fx-text-fill: #1E2346; -fx-font-size: 20px; -fx-font-weight: bold;");

        TableView<Transaction> table = new TableView<>();
        table.setPrefHeight(230);

        TableColumn<Transaction, String> colId = new TableColumn<>("Txn ID");
        colId.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getId()));

        TableColumn<Transaction, String> colType = new TableColumn<>("Category / Service");
        colType.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getType()));

        TableColumn<Transaction, String> colAmt = new TableColumn<>("Amount (₹)");
        colAmt.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getAmount()));

        TableColumn<Transaction, String> colDate = new TableColumn<>("Timestamp");
        colDate.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getDate()));

        TableColumn<Transaction, String> colStatus = new TableColumn<>("Status");
        colStatus.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getStatus()));

        table.getColumns().addAll(colId, colType, colAmt, colDate, colStatus);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        ObservableList<Transaction> transactionsList = FXCollections.observableArrayList(
            new Transaction("NVR-EDU-901", "Education Loan Disbursal", "₹ +4,50,000.00", "09 Nov 2026, 10:15 AM", "DISBURSED"),
            new Transaction("NVR-FD-801", "Fixed Deposit Interest Payout", "₹ +43,562.93", "08 Nov 2026, 04:00 PM", "CREDITED"),
            new Transaction("NVR-GLD-702", "Gold Loan Sanction Credit", "₹ +2,50,000.00", "05 Nov 2026, 03:15 PM", "DISBURSED"),
            new Transaction("NVR-EDU-603", "College Tuition Fee Paid", "₹ -1,20,000.00", "02 Nov 2026, 11:30 AM", "COMPLETED"),
            new Transaction("NVR-INS-504", "Health Insurance Premium", "₹ -14,200.00", "01 Nov 2026, 02:45 PM", "ACTIVE"),
            new Transaction("NVR-PAN-405", "PAN Verification Charge", "₹ -110.00", "28 Oct 2026, 09:15 AM", "VERIFIED")
        );
        table.setItems(transactionsList);

        bottomSection.getChildren().addAll(servicesTitle, servicesGrid, fdContainer, whyTitle, table);

        rootBox.getChildren().addAll(heroSection, bottomSection);

        ScrollPane scrollPane = new ScrollPane(rootBox);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background: #FFFFFF; -fx-background-color: transparent;");

        return scrollPane;
    }

    private VBox createLightServiceCard(String title, String desc, String btnText) {
        VBox card = new VBox(10);
        card.setStyle("-fx-background-color: #F8FAFC; -fx-padding: 16px; -fx-background-radius: 12px; -fx-border-color: #E2E8F0; -fx-border-radius: 12px;");

        Label t = new Label(title);
        t.setStyle("-fx-text-fill: #1E2346; -fx-font-size: 14px; -fx-font-weight: bold;");

        Label d = new Label(desc);
        d.setStyle("-fx-text-fill: #64748B; -fx-font-size: 11px;");

        Button b = new Button(btnText);
        b.setStyle("-fx-background-color: linear-gradient(to right, #FF5A78, #FF8359); -fx-text-fill: #FFFFFF; -fx-font-weight: bold; -fx-font-size: 12px; -fx-background-radius: 18px; -fx-padding: 8px 16px; -fx-cursor: hand;");
        b.setMaxWidth(Double.MAX_VALUE);

        b.setOnAction(e -> NavigationController.showAlert(Alert.AlertType.INFORMATION, title, title + " portal opened successfully!"));

        card.getChildren().addAll(t, d, b);
        return card;
    }

    private void addFloatingAnimation(javafx.scene.Node node, double translateY, double durationSeconds) {
        TranslateTransition floating = new TranslateTransition(Duration.seconds(durationSeconds), node);
        floating.setByY(translateY);
        floating.setAutoReverse(true);
        floating.setCycleCount(Animation.INDEFINITE);
        floating.setInterpolator(Interpolator.EASE_BOTH);
        floating.play();
    }
}