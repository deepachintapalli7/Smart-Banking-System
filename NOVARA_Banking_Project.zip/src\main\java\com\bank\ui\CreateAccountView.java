package com.bank.ui;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

public class CreateAccountView {
    public static VBox getView() {
        VBox card = new VBox(15);
        card.getStyleClass().add("card-panel");
        card.setPadding(new Insets(20));
        card.setMaxWidth(500);

        Label title = new Label("Create New Account");
        title.getStyleClass().add("header-text");

        TextField nameField = new TextField();
        nameField.setPromptText("Customer Name");
        nameField.getStyleClass().add("text-input-field");

        TextField userField = new TextField();
        userField.setPromptText("Username");
        userField.getStyleClass().add("text-input-field");

        PasswordField passField = new PasswordField();
        passField.setPromptText("Password");
        passField.getStyleClass().add("text-input-field");

        ComboBox<String> typeBox = new ComboBox<>();
        typeBox.getItems().addAll("Savings Account", "Current Account");
        typeBox.getSelectionModel().selectFirst();
        typeBox.setMaxWidth(Double.MAX_VALUE);

        TextField depField = new TextField();
        depField.setPromptText("Initial Deposit (₹)");
        depField.getStyleClass().add("text-input-field");

        Button submitBtn = new Button("Create Account");
        submitBtn.getStyleClass().add("primary-button");

        submitBtn.setOnAction(e -> {
            if (nameField.getText().trim().isEmpty() || userField.getText().trim().isEmpty() || 
                passField.getText().trim().isEmpty() || depField.getText().trim().isEmpty()) {
                NavigationController.showAlert(Alert.AlertType.ERROR, "Validation Error", "All fields are required.");
                return;
            }
            try {
                double amount = Double.parseDouble(depField.getText());
                if (amount <= 0) {
                    NavigationController.showAlert(Alert.AlertType.ERROR, "Validation Error", "Initial deposit must be greater than zero.");
                    return;
                }
                NavigationController.showAlert(Alert.AlertType.INFORMATION, "Success", "Account creation request submitted to backend.");
            } catch (NumberFormatException ex) {
                NavigationController.showAlert(Alert.AlertType.ERROR, "Validation Error", "Initial deposit must be a valid number.");
            }
        });

        card.getChildren().addAll(title, nameField, userField, passField, typeBox, depField, submitBtn);
        return new VBox(card) {{ setPadding(new Insets(20)); }};
    }
}
